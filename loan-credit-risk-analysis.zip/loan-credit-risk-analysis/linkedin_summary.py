"""
linkedin_summary.py
--------------------
Combines all risk-analysis charts + key stats into ONE image for sharing.
"""

import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec
import matplotlib.patheffects as pe

from risk_analysis import load_and_clean, compute_metrics

PALETTE = "#4C72B0"
ACCENT = "#C44E52"
GREY = "#B0B0B0"
DARK = "#2B2B2B"


def main():
    df = load_and_clean()
    m = compute_metrics(df)

    fig = plt.figure(figsize=(11, 13), dpi=200, facecolor="white")
    gs = gridspec.GridSpec(
        5, 2,
        height_ratios=[0.85, 1.6, 1.6, 1.6, 0.55],
        hspace=0.5, wspace=0.32,
        left=0.08, right=0.95, top=0.95, bottom=0.02,
    )

    # ---------- Header ----------
    ax_header = fig.add_subplot(gs[0, :])
    ax_header.axis("off")
    ax_header.text(0, 1.0, "Loan & Credit Risk Analysis", fontsize=26,
                    fontweight="bold", color=DARK, ha="left", va="top")
    ax_header.text(0, 0.62, "Which borrower factors drive loan defaults — and where to tighten underwriting",
                    fontsize=13, color="#555555", ha="left", va="top")

    worst_grade = m["by_grade"].idxmax()
    kpis = [
        (f"{m['overall_rate']:.1%}", "Overall\ndefault rate"),
        (f"AED {m['exposure_at_risk']/1e6:.1f}M", "Exposure at\nrisk (defaults)"),
        (f"Grade {worst_grade}", f"Highest-risk grade\n({m['by_grade'].max():.0%} default)"),
        ("DTI > 30%", "Highest-risk\nDTI band"),
    ]
    n = len(kpis)
    for i, (val, label) in enumerate(kpis):
        x = i / n
        ax_header.text(x, 0.10, val, fontsize=17, fontweight="bold", color=ACCENT, ha="left", va="top")
        ax_header.text(x, -0.15, label, fontsize=10, color="#555555", ha="left", va="top")
    ax_header.set_xlim(0, 1)
    ax_header.set_ylim(-0.3, 1)

    # ---------- 1. Default by grade ----------
    ax1 = fig.add_subplot(gs[1, 0])
    stats = df.groupby("grade", observed=True)["is_default"].mean()
    colors = [ACCENT if g in ["E", "F", "G"] else PALETTE for g in stats.index]
    bars = ax1.bar(stats.index.astype(str), stats.values * 100, color=colors)
    for bar, v in zip(bars, stats.values):
        ax1.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.8,
                  f"{v:.0%}", ha="center", fontsize=9)
    ax1.set_title("Default Rate by Grade")
    ax1.set_ylabel("Default rate (%)", fontsize=9)
    ax1.spines[["top", "right"]].set_visible(False)
    ax1.tick_params(labelsize=9)

    # ---------- 2. Default by DTI ----------
    ax2 = fig.add_subplot(gs[1, 1])
    stats2 = df.groupby("dti_band", observed=True)["is_default"].mean()
    colors2 = [ACCENT if v == stats2.max() else PALETTE for v in stats2.values]
    bars2 = ax2.bar(stats2.index.astype(str), stats2.values * 100, color=colors2)
    for bar, v in zip(bars2, stats2.values):
        ax2.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.5,
                  f"{v:.0%}", ha="center", fontsize=9)
    ax2.set_title("Default Rate by DTI Band")
    ax2.set_xlabel("DTI (%)", fontsize=9)
    ax2.set_ylabel("Default rate (%)", fontsize=9)
    ax2.spines[["top", "right"]].set_visible(False)
    ax2.tick_params(labelsize=9)

    # ---------- 3. Income vs rate scatter ----------
    ax3 = fig.add_subplot(gs[2, 0])
    sample = df.sample(min(1500, len(df)), random_state=1)
    colors3 = [ACCENT if d else PALETTE for d in sample["is_default"]]
    ax3.scatter(sample["annual_income"], sample["interest_rate"], c=colors3, alpha=0.35, s=12, edgecolors="none")
    ax3.set_xscale("log")
    ax3.set_title("Income vs Interest Rate")
    ax3.set_xlabel("Annual income (log)", fontsize=9)
    ax3.set_ylabel("Interest rate (%)", fontsize=9)
    ax3.spines[["top", "right"]].set_visible(False)
    ax3.tick_params(labelsize=9)

    # ---------- 4. Default by purpose ----------
    ax4 = fig.add_subplot(gs[2, 1])
    stats4 = df.groupby("purpose")["is_default"].mean().sort_values()
    bars4 = ax4.barh(stats4.index, stats4.values * 100, color=PALETTE)
    for bar, v in zip(bars4, stats4.values):
        ax4.text(bar.get_width() + 0.4, bar.get_y() + bar.get_height() / 2,
                  f"{v:.0%}", va="center", fontsize=8)
    ax4.set_title("Default Rate by Purpose (weak signal)")
    ax4.set_xlabel("Default rate (%)", fontsize=9)
    ax4.spines[["top", "right"]].set_visible(False)
    ax4.tick_params(labelsize=8)

    # ---------- 5. Grade x home ownership heatmap ----------
    ax5 = fig.add_subplot(gs[3, 0])
    pivot = df.pivot_table(index="grade", columns="home_ownership",
                            values="is_default", aggfunc="mean", observed=True)
    im = ax5.imshow(pivot.values * 100, cmap="YlOrRd", aspect="auto")
    ax5.set_xticks(range(len(pivot.columns)))
    ax5.set_xticklabels(pivot.columns, fontsize=9)
    ax5.set_yticks(range(len(pivot.index)))
    ax5.set_yticklabels(pivot.index.astype(str), fontsize=9)
    for i in range(pivot.shape[0]):
        for j in range(pivot.shape[1]):
            v = pivot.values[i, j]
            ax5.text(j, i, f"{v*100:.0f}%", ha="center", va="center", fontsize=9,
                      color="black", fontweight="bold",
                      path_effects=[pe.withStroke(linewidth=3, foreground="white")])
    ax5.set_title("Default Rate: Grade × Home Ownership")

    # ---------- 6. Recommendations ----------
    ax6 = fig.add_subplot(gs[3, 1])
    ax6.axis("off")
    ax6.text(0, 1.0, "Recommendations", fontsize=13, fontweight="bold", color=DARK, va="top")
    recs = [
        "Tighten underwriting or reprice\nGrade E/F/G applicants",
        "Flag DTI > 30% as a hard\nunderwriting review trigger",
        "Grade & DTI remain the\nprimary risk drivers",
    ]
    y = 0.82
    for r in recs:
        ax6.text(0, y, "•", fontsize=13, color=ACCENT, va="top")
        ax6.text(0.06, y, r, fontsize=10, color="#333333", va="top")
        y -= 0.30
    ax6.set_xlim(0, 1)
    ax6.set_ylim(0, 1)

    # ---------- Footer ----------
    ax_foot = fig.add_subplot(gs[4, :])
    ax_foot.axis("off")
    ax_foot.text(0, 1.0, f"Based on {len(df):,} loans  |  Python, pandas, Matplotlib  |  "
                          "Data cleaning + EDA + risk segmentation",
                 fontsize=10, color="#666666", va="top")
    ax_foot.text(0, 0.35, "Muhamed Aslam", fontsize=12, fontweight="bold", color=DARK, va="top")
    ax_foot.set_xlim(0, 1)
    ax_foot.set_ylim(0, 1)

    fig.savefig("charts/linkedin_summary.png", bbox_inches="tight", facecolor="white")
    print("Saved charts/linkedin_summary.png")


if __name__ == "__main__":
    main()
