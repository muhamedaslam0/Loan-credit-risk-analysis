"""
generate_data.py
-----------------
Generates a synthetic but realistically-distributed consumer loan dataset,
modeled on the structure of public loan datasets (e.g. LendingClub) so the
project is reproducible with no external downloads or API keys.

Encodes real credit-risk patterns:
- Lower loan grade (D/E/F/G) -> much higher default rate
- Higher debt-to-income (DTI) -> higher default rate
- Shorter employment length & renters -> slightly higher default rate
- Higher interest rate correlates with grade (riskier loans priced higher)

Swap data/loans.csv for a real dataset (e.g. Kaggle's "Lending Club Loan
Data") with matching column names to run this on real data.
"""

import numpy as np
import pandas as pd
from datetime import timedelta

np.random.seed(7)

N_LOANS = 10000

GRADES = ["A", "B", "C", "D", "E", "F", "G"]
GRADE_WEIGHTS = [0.16, 0.24, 0.24, 0.16, 0.10, 0.06, 0.04]
GRADE_BASE_DEFAULT = {"A": 0.03, "B": 0.07, "C": 0.13, "D": 0.20, "E": 0.28, "F": 0.36, "G": 0.45}
GRADE_RATE_RANGE = {  # interest rate range by grade
    "A": (6, 9), "B": (9, 12), "C": (12, 16), "D": (16, 20),
    "E": (20, 24), "F": (24, 28), "G": (28, 31),
}

PURPOSES = ["Debt consolidation", "Credit card refinance", "Home improvement",
            "Auto", "Business", "Medical", "Other"]
PURPOSE_WEIGHTS = [0.38, 0.22, 0.12, 0.08, 0.08, 0.06, 0.06]

HOME_OWNERSHIP = ["RENT", "MORTGAGE", "OWN"]
HOME_WEIGHTS = [0.42, 0.44, 0.14]

TERMS = [36, 60]
TERM_WEIGHTS = [0.7, 0.3]


def random_dates(n, start="2023-01-01", end="2025-12-31"):
    start_ts = pd.Timestamp(start)
    end_ts = pd.Timestamp(end)
    days = (end_ts - start_ts).days
    offsets = np.random.randint(0, days, size=n)
    return [start_ts + timedelta(days=int(d)) for d in offsets]


def generate():
    loan_id = np.arange(500000, 500000 + N_LOANS)
    grade = np.random.choice(GRADES, size=N_LOANS, p=GRADE_WEIGHTS)
    issue_date = random_dates(N_LOANS)

    loan_amount = np.round(np.random.uniform(1000, 40000, size=N_LOANS), -2)
    term = np.random.choice(TERMS, size=N_LOANS, p=TERM_WEIGHTS)

    interest_rate = np.array([
        round(np.random.uniform(*GRADE_RATE_RANGE[g]), 2) for g in grade
    ])

    annual_income = np.round(np.random.lognormal(mean=10.9, sigma=0.45, size=N_LOANS), -2)
    annual_income = np.clip(annual_income, 15000, 400000)

    dti = np.round(np.random.gamma(shape=3.2, scale=6.0, size=N_LOANS), 1)
    dti = np.clip(dti, 0, 55)

    emp_length = np.random.choice(
        ["<1 year", "1-3 years", "4-6 years", "7-9 years", "10+ years"],
        size=N_LOANS, p=[0.15, 0.28, 0.24, 0.15, 0.18]
    )
    home_ownership = np.random.choice(HOME_OWNERSHIP, size=N_LOANS, p=HOME_WEIGHTS)
    purpose = np.random.choice(PURPOSES, size=N_LOANS, p=PURPOSE_WEIGHTS)

    credit_score = np.round(np.clip(
        850 - (GRADES.index("A") * 0) - np.array([GRADES.index(g) for g in grade]) * 35
        - np.random.normal(0, 20, size=N_LOANS), 580, 850
    ))

    # Default probability driven by grade (dominant), DTI, employment length, home ownership
    base = np.array([GRADE_BASE_DEFAULT[g] for g in grade])
    dti_bump = np.where(dti > 30, 0.08, np.where(dti > 20, 0.03, 0.0))
    emp_bump = np.where(np.isin(emp_length, ["<1 year", "1-3 years"]), 0.03, 0.0)
    rent_bump = np.where(home_ownership == "RENT", 0.02, 0.0)
    default_prob = np.clip(base + dti_bump + emp_bump + rent_bump, 0.01, 0.9)

    is_default = np.random.binomial(1, default_prob)

    df = pd.DataFrame({
        "loan_id": loan_id,
        "issue_date": issue_date,
        "loan_amount": loan_amount,
        "term_months": term,
        "interest_rate": interest_rate,
        "grade": pd.Categorical(grade, categories=GRADES, ordered=True),
        "annual_income": annual_income,
        "dti": dti,
        "emp_length": emp_length,
        "home_ownership": home_ownership,
        "purpose": purpose,
        "credit_score": credit_score.astype(int),
        "is_default": is_default.astype(bool),
    })

    # Realistic data-quality issues for the cleaning step
    dup_rows = df.sample(35, random_state=1)
    df = pd.concat([df, dup_rows], ignore_index=True)
    missing_idx = df.sample(frac=0.015, random_state=2).index
    df.loc[missing_idx, "emp_length"] = np.nan
    df.loc[df.sample(20, random_state=3).index, "annual_income"] = -1  # bad entries

    return df


if __name__ == "__main__":
    df = generate()
    df.to_csv("data/loans.csv", index=False)
    print(f"Generated {len(df)} rows -> data/loans.csv")
    print(f"Overall default rate (raw): {df['is_default'].mean():.2%}")
